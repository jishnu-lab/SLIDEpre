##' Response data from Var50.
##'
##' Example data for the Essential Regression vignette.
##'
##' @format A data frame with 24 rows and 1 column.
##'
"y_data"
